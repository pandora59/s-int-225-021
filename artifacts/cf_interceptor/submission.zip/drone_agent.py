from __future__ import annotations
import math
from collections import deque
from typing import Optional
import numpy as np
try:
    from scipy import ndimage as _ndimage
except Exception:
    _ndimage = None
CONTROL_HZ = 50.0
DT = 1.0 / CONTROL_HZ
MAX_SPEED = 6.0
TARGET_CRUISE_FRAC = 0.45
TARGET_FLEE_FRAC = 0.75
LEASH_M = 55.0
REACT_M = 12.0
KILL_RADIUS_M = 0.15
TARGET_ALT_MIN_M = 3.0
TARGET_ALT_MAX_M = 25.0
CLUE_REFRESH_S = 2.0
MAX_RAY_DISTANCE_M = 20.0
SELF_SPEED_EFF = 0.859
CRUISE_OVERSHOOT = 1.249
FLEE_OVERSHOOT = 1.053
ACHIEVED_SPEED_MPS = MAX_SPEED * SELF_SPEED_EFF
CRUISE_MPS = MAX_SPEED * TARGET_CRUISE_FRAC * CRUISE_OVERSHOOT
FLEE_MPS = MAX_SPEED * TARGET_FLEE_FRAC * FLEE_OVERSHOOT
STERN_CLOSING_MPS = ACHIEVED_SPEED_MPS - FLEE_MPS
HEADON_CLOSING_MPS = ACHIEVED_SPEED_MPS + CRUISE_MPS
CRUISE_SPINUP_S = 0.95
LEASH_ARRIVAL_S = LEASH_M / CRUISE_MPS + CRUISE_SPINUP_S
COMMIT_DWELL_S = 4.0
COMMIT_HOLD_M = 14.0
COMMIT_HOLD_GAIN = 1.2
COMMIT_APPROACH_MPS = -1.5
COMMIT_TERMINAL_M = 2.0
COMMIT_RDOT_SMOOTH = 0.8
COMMIT_HOLD_KR = 1.0
COMMIT_HOLD_KT = 0.55
COMMIT_HOLD_TAPER_DEG = 35.0
WOBBLE_AMP = 0.2
WOBBLE_RATE = 0.1
DEPTH_FOV_DEG = 90.28
DEPTH_MIN_M = 0.5
DEPTH_MAX_M = 100.0
CAM_FORWARD_OFFSET_M = 0.13
CAM_UP_OFFSET_M = 0.05
TARGET_BODY_RADIUS_M = 0.18
PROFILE = {'aim': 'pinned', 'sweep': 'when_unpinned', 'home': 'detection', 'home_window': 'until_cutoff', 'engagement': 'leash_wait', 'altitude': 'hold_locked', 'lock_overturn': 'hard', 'pursuit': 'altitude_first', 'takeoff_gate': 'latched', 'detector': 'permissive', 'trajectory': 'direct', 'heading_bias': 'none', 'pace': 'max', 'approach': 'staged', 'station_pin': 'track', 'commit': 'dwell', 'pursuit_fallback': 'pinned', 'hold': 'point', 'hold_release': 'target_only', 'climb_floor': 'exit_gate'}
TUNING = {'perception': {'detect_max_range_m': 90.0, 'detect_pool': 4, 'detect_gate_m': 18.0, 'contrast_m': 1.0}, 'altitude': {'search_agl_m': 14.0, 'z_gate_m': 1.6, 'z_spread_m': 0.75, 'rival_min': 20, 'stale_s': 6.0}, 'engagement': {'standoff_m': 14.0, 'arrival_margin_m': 2.0, 'pin_fresh_s': 3.0, 'det_home_min': 40}, 'flight': {'max_tilt_deg': 75.0, 'normal_accel': 7.0, 'terminal_accel': 14.0, 'alt_match_gain': 1.5}, 'estimator': {'heading_min_samples': 12, 'home_sample_until_s': 15.5}}
CLUE_JUMP_M = 1.0
HEADING_MIN_SAMPLES = 12
HEADING_SPEED_LO = 0.35
HEADING_SPEED_HI = 2.5
HOME_SAMPLE_UNTIL_S = 15.5
ARRIVAL_BACK_M = 13.0
ARRIVAL_LATERAL_M = 13.0
ARRIVAL_SETTLE_M = 2.5
STATION_ALONG_M = 20.68
STATION_CROSS_M = 3.65
STAGING_M = 13.0
HEADING_BIAS_K = 0.15
HEADING_BIAS_F = 0.1
HEADING_BIAS_FADE_M = 18.0
PACE_MIN_MPS = 1.5
STRETCH_DIRECT_MAX = 1.15
STRETCH_BOW_MAX = 1.6
STRETCH_S_MAX = 2.6
STRETCH_ORBIT_R_M = 10.0
STRETCH_ORBIT_LEAD_RAD = 0.55
STRETCH_MAX_SAGITTA_FRAC = 0.75
SEARCH_AGL_M = 14.0
CLIMB_EXIT_AGL_M = 6.0
TRACK_MIN_AGL_M = 2.5
MAX_CLIMB_MPS = 3.0
ALT_MATCH_GAIN = 1.5
ALT_MATCH_DEADBAND_M = 0.4
ALT_GAIN = 1.2
DETECT_MAX_RANGE_M = 90.0
DETECT_POOL = 4
DETECT_MAX_BLOB_PX = 400
DETECT_MIN_BLOB_PX = 1
DETECT_GATE_M = 18.0
DETECT_BG_WINDOW = 13
DETECT_CONTRAST_M = 1.0
DETECT_BG_CAP_M = 60.0
DETECT_MAX_BLOB_FRAC = 0.2
DETECT_Z_PRIOR_MIN_M = 1.8
DETECT_Z_PRIOR_MAX_M = 26.3
DETECT_MERGED_MIN_FRAC = 0.01
DETECT_MERGED_WIDTH_FRAC = 0.75
DETECT_MERGED_SPAN_M = 5.0
DETECT_DISTANT_MIN_RANGE_M = 5.0
DETECT_DISTANT_MAX_FRAC = 0.01
DETECT_FLOOR_MAX_FRAC = 0.01
DETECT_Z_GATE_M = 1.6
DETECT_Z_HISTORY = 15
DETECT_Z_MIN_LOCK = 3
DETECT_Z_WINDOW_S = 2.0
DETECT_Z_SPREAD_M = 0.75
DETECT_Z_RELEASE_S = 3.0
DETECT_Z_STALE_EASY_S = 1.0
DETECT_Z_STALE_S = 6.0
DETECT_Z_RIVAL_MIN = 20
DETECT_Z_RIVAL_WINDOW_S = 4.0
TRACK_MEMORY_S = 1.0
PURSUE_LEAD_S = 0.45
TERMINAL_RANGE_M = 3.5
TERMINAL_LEAD_S = 0.18
PN_GAIN = 3.4
PN_MAX_LATERAL = 26.0
STANDOFF_HOLD_M = 12.6
DET_HOME_MIN = 40
OFFSET_PIN_FRESH_S = 3.0
ENGAGE_STANDOFF_M = 14.0
ENGAGE_ARRIVAL_MARGIN_M = 2.0
SWEEP_AMP_DEG = 22.0
SWEEP_PERIOD_S = 2.4
MAX_TILT_DEG = 75.0
TILT_BRAKE_START_DEG = 30.0
TILT_BRAKE_FULL_DEG = 58.0
TILT_BRAKE_MIN_FRACTION = 0.1
NORMAL_MAX_ACCEL = 7.0
TERMINAL_MAX_ACCEL = 14.0
TERMINAL_ACCEL_RANGE_M = 6.0

def _unit(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-09 else np.zeros_like(v)

def _wrap(a: float) -> float:
    return (a + math.pi) % (2.0 * math.pi) - math.pi

def _limit(v: np.ndarray, cap: float) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v * (cap / n) if n > cap and n > 1e-09 else v

def _rot_world_from_body(rpy: np.ndarray) -> np.ndarray:
    cr, sr = (math.cos(float(rpy[0])), math.sin(float(rpy[0])))
    cp, sp = (math.cos(float(rpy[1])), math.sin(float(rpy[1])))
    cy, sy = (math.cos(float(rpy[2])), math.sin(float(rpy[2])))
    return np.array([[cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr], [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr], [-sp, cp * sr, cp * cr]], dtype=np.float64)

def _encode(velocity: np.ndarray, yaw: float) -> np.ndarray:
    v = np.asarray(velocity, dtype=np.float64)
    speed = float(np.linalg.norm(v))
    if speed < 1e-06:
        direction = np.array([1.0, 0.0, 0.0])
        throttle = 0.0
    else:
        direction = v / speed
        throttle = min(1.0, speed / MAX_SPEED)
    return np.array([direction[0], direction[1], direction[2], float(np.clip(throttle, 0.0, 1.0)), float(np.clip(_wrap(yaw) / math.pi, -1.0, 1.0))], dtype=np.float32)

def _arc_angle_for_stretch(stretch: float) -> float:
    if stretch <= 1.0 + 1e-09:
        return 0.0
    lo, hi = (1e-06, math.pi - 1e-06)
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        if mid / math.sin(mid) < stretch:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def _stretch_waypoint(pos: np.ndarray, goal: np.ndarray, t_remaining: float, side: float, keep_clear: Optional[np.ndarray]=None) -> np.ndarray:
    to_goal = np.asarray(goal, dtype=np.float64) - np.asarray(pos, dtype=np.float64)
    d = float(np.linalg.norm(to_goal))
    if d < 1e-06:
        return np.asarray(goal, dtype=np.float64)
    travel = max(0.0, t_remaining) * ACHIEVED_SPEED_MPS
    stretch = travel / d
    if stretch <= STRETCH_DIRECT_MAX:
        return np.asarray(goal, dtype=np.float64)
    chord = to_goal / d
    lateral = np.array([-chord[1], chord[0]], dtype=np.float64) * side
    if stretch <= STRETCH_S_MAX:
        halves = 1.0 if stretch <= STRETCH_BOW_MAX else 2.0
        u = _arc_angle_for_stretch(stretch)
        sag = d / (2.0 * halves) * math.tan(min(u, math.pi / 2 - 0.001) / 2.0)
        sag = min(sag, STRETCH_MAX_SAGITTA_FRAC * d)
        if halves == 1.0:
            return np.asarray(pos, dtype=np.float64) + chord * (d * 0.5) + lateral * sag
        return np.asarray(pos, dtype=np.float64) + chord * (d * 0.25) + lateral * sag
    R = STRETCH_ORBIT_R_M
    ref = np.asarray(keep_clear, dtype=np.float64) if keep_clear is not None else np.asarray(goal, dtype=np.float64) - chord * (ENGAGE_STANDOFF_M + R)
    axis = np.asarray(goal, dtype=np.float64) - ref
    n = float(np.linalg.norm(axis))
    axis = axis / n if n > 1e-06 else chord
    centre = ref + axis * (ENGAGE_STANDOFF_M + R)
    rel = np.asarray(pos, dtype=np.float64) - centre
    r = float(np.linalg.norm(rel))
    if r < 1e-06:
        rel, r = (-axis, 1.0)
    radial = rel / r
    tangent = np.array([-radial[1], radial[0]], dtype=np.float64) * side
    pull = float(np.clip((r - R) / max(R, 1e-06), -1.0, 1.0))
    direction = _unit(tangent - radial * pull)
    return np.asarray(pos, dtype=np.float64) + direction * STRETCH_ORBIT_R_M

def _arc_offset(cruise_heading: float, radius: float=LEASH_M) -> tuple[np.ndarray, float]:
    step = 0.05
    pos = np.zeros(2, dtype=np.float64)
    t = 0.0
    while t < 60.0:
        ang = cruise_heading + WOBBLE_AMP * math.sin(WOBBLE_RATE * t)
        pos = pos + CRUISE_MPS * step * np.array([math.cos(ang), math.sin(ang)])
        t += step
        if float(np.linalg.norm(pos)) >= radius:
            break
    return (pos, t)

class LeashEstimator:

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.clue: Optional[np.ndarray] = None
        self.home: Optional[np.ndarray] = None
        self.cruise_heading: Optional[float] = None
        self.leash_point: Optional[np.ndarray] = None
        self.target_est: Optional[np.ndarray] = None
        self.leash_time: Optional[float] = None
        self.ready = False
        self.windows = 0
        self._prev_clue: Optional[np.ndarray] = None
        self._clue_velocity = np.zeros(2, dtype=np.float64)
        self._heading_sin = 0.0
        self._heading_cos = 0.0
        self._heading_n = 0
        self._speed_sum = 0.0
        self._speed_n = 0
        self._anchor: Optional[np.ndarray] = None
        self._home_sum = np.zeros(2, dtype=np.float64)
        self._home_n = 0
        self._anchor_sum = np.zeros(2, dtype=np.float64)
        self._anchor_n = 0
        self._det_home_sum = np.zeros(2, dtype=np.float64)
        self._det_home_n = 0
        self._offset: Optional[np.ndarray] = None
        self._offset_t = -1000000000.0
        self._arc_ch: Optional[float] = None
        self._arc_xy: Optional[np.ndarray] = None
        self._arc_dt = 0.05
        self._arc_apex_t = 0.0

    def update(self, t: float, own_xy: np.ndarray, clue_offset_xy: np.ndarray) -> None:
        clue = np.asarray(own_xy, dtype=np.float64) + np.asarray(clue_offset_xy, dtype=np.float64)
        self.clue = clue
        if self._prev_clue is None:
            self._anchor = clue.copy()
            self.home = clue.copy()
            self._prev_clue = clue.copy()
            return
        step = clue - self._prev_clue
        step_len = float(np.linalg.norm(step))
        lo = HEADING_SPEED_LO * CRUISE_MPS * DT
        hi = HEADING_SPEED_HI * CRUISE_MPS * DT
        if step_len > CLUE_JUMP_M:
            predicted = self._prev_clue + self._clue_velocity * DT
            if self._offset is not None:
                self._offset = self._offset + (clue - predicted)
            if self._anchor is not None:
                self._anchor = self._anchor + (clue - predicted)
                self._anchor_sum = self._anchor_sum + self._anchor
                self._anchor_n += 1
            self.windows += 1
        elif lo <= step_len <= hi:
            self._clue_velocity = step / DT
            angle = math.atan2(float(step[1]), float(step[0]))
            base = angle - WOBBLE_AMP * math.sin(WOBBLE_RATE * t)
            self._heading_sin += math.sin(base)
            self._heading_cos += math.cos(base)
            self._heading_n += 1
            self._speed_sum += step_len / DT
            self._speed_n += 1
            if self._heading_n >= HEADING_MIN_SAMPLES:
                self.cruise_heading = math.atan2(self._heading_sin, self._heading_cos)
                self.ready = True
        if self.ready and t <= HOME_SAMPLE_UNTIL_S:
            self._build_arc()
            displacement = self._displacement(t)
            if displacement is not None:
                self._home_sum += clue - displacement
                self._home_n += 1
        self._update_products()
        self._prev_clue = clue.copy()

    def pin_offset(self, t: float, target_xy: np.ndarray) -> None:
        if self.clue is None:
            return
        self._offset = self.clue - np.asarray(target_xy, dtype=np.float64)[:2]
        self._offset_t = t
        self._update_products()

    def pin_age(self, t: float) -> float:
        return t - self._offset_t

    def pinned_target(self, t: float) -> Optional[np.ndarray]:
        if self._offset is None or self.clue is None:
            return None
        if self.pin_age(t) > OFFSET_PIN_FRESH_S:
            return None
        return self.clue - self._offset

    def observe_target(self, t: float, target_xy: np.ndarray) -> None:
        if not self.ready:
            return
        if t > HOME_SAMPLE_UNTIL_S:
            return
        self._build_arc()
        displacement = self._displacement(t)
        if displacement is None:
            return
        self._det_home_sum += np.asarray(target_xy, dtype=np.float64)[:2] - displacement
        self._det_home_n += 1
        self._update_products()

    def _build_arc(self) -> None:
        ch = self.cruise_heading
        if ch is None:
            return
        if self._arc_ch is not None and abs(_wrap(ch - self._arc_ch)) < 0.01 and (self._arc_xy is not None):
            return
        step = self._arc_dt
        pts = [np.zeros(2, dtype=np.float64)]
        pos = np.zeros(2, dtype=np.float64)
        tt = 0.0
        apex_t = 0.0
        while tt < 40.0:
            ang = ch + WOBBLE_AMP * math.sin(WOBBLE_RATE * tt)
            pos = pos + CRUISE_MPS * step * np.array([math.cos(ang), math.sin(ang)])
            tt += step
            pts.append(pos.copy())
            if apex_t == 0.0 and float(np.linalg.norm(pos)) >= LEASH_M:
                apex_t = tt
                break
        self._arc_ch = ch
        self._arc_xy = np.stack(pts)
        self._arc_apex_t = (apex_t if apex_t > 0.0 else tt) + CRUISE_SPINUP_S

    def _displacement(self, t: float) -> Optional[np.ndarray]:
        if self._arc_xy is None:
            return None
        idx = int(round(max(0.0, t - CRUISE_SPINUP_S) / self._arc_dt))
        if idx < 0:
            return None
        if idx >= len(self._arc_xy):
            idx = len(self._arc_xy) - 1
        return self._arc_xy[idx]

    def _update_products(self) -> None:
        if self._det_home_n >= DET_HOME_MIN:
            self.home = self._det_home_sum / self._det_home_n
        elif self._home_n > 0:
            self.home = self._home_sum / self._home_n
        elif self._anchor is not None:
            self.home = self._anchor
        if self.home is not None and self._arc_xy is not None:
            self.leash_point = self.home + self._arc_xy[-1]
            self.leash_time = self._arc_apex_t
        if self.clue is not None and self._offset is not None:
            self.target_est = self.clue - self._offset
        elif self.clue is not None and self._anchor is not None and (self.home is not None):
            self.target_est = self.clue - self._anchor + self.home

    @property
    def measured_speed(self) -> float:
        return self._speed_sum / self._speed_n if self._speed_n else CRUISE_MPS

    def _axis(self):
        if self.leash_point is None or self.home is None:
            return None
        u = _unit(self.leash_point - self.home)
        if float(np.linalg.norm(u)) < 1e-06:
            return None
        return (u, np.array([-u[1], u[0]], dtype=np.float64))

    def station_point(self, drone_xy: np.ndarray) -> Optional[np.ndarray]:
        ax = self._axis()
        if ax is None:
            return None
        u, v = ax
        base = self.leash_point - STATION_ALONG_M * u
        d = np.asarray(drone_xy, dtype=np.float64)
        if float(np.dot(d - self.home, v)) < 0.0:
            v = -v
        return base + STATION_CROSS_M * v

    def staging_point(self, drone_xy: np.ndarray) -> Optional[np.ndarray]:
        S = self.station_point(drone_xy)
        ax = self._axis()
        if S is None or ax is None:
            return None
        u, v = ax
        base = self.leash_point - STATION_ALONG_M * u
        if float(np.dot(S - base, v)) < 0.0:
            v = -v
        C = np.asarray(drone_xy, dtype=np.float64)
        if float(np.dot(C - S, u)) > 0.0:
            return S + STAGING_M * v
        n = C - S
        ln = float(np.linalg.norm(n))
        if ln < 1e-06:
            return S + STAGING_M * v
        return S + STAGING_M * (n / ln)

    def arrival_point(self, drone_xy: np.ndarray) -> Optional[np.ndarray]:
        if self.leash_point is None or self.home is None:
            return None
        radial = _unit(self.leash_point - self.home)
        if float(np.linalg.norm(radial)) < 1e-06:
            return None
        lateral = np.array([-radial[1], radial[0]], dtype=np.float64)
        base = self.leash_point - ARRIVAL_BACK_M * radial
        d = np.asarray(drone_xy, dtype=np.float64)
        if float(np.dot(d - self.home, lateral)) < 0.0:
            lateral = -lateral
        return base + ARRIVAL_LATERAL_M * lateral

class DepthTargetDetector:

    def __init__(self) -> None:
        self._labels_buf = None
        self.last_shadow: Optional[np.ndarray] = None

    def detect(self, depth, drone_pos: np.ndarray, drone_rpy: np.ndarray, expected_world: Optional[np.ndarray], gate_m: float, target_z: Optional[float]=None) -> Optional[np.ndarray]:
        self.last_shadow = None
        if depth is None:
            return None
        img = np.asarray(depth, dtype=np.float32)
        if img.ndim == 3:
            img = img[:, :, 0]
        if img.ndim != 2 or img.size == 0:
            return None
        h, w = img.shape
        pool = DETECT_POOL
        ph, pw = (h // pool, w // pool)
        if ph == 0 or pw == 0:
            return None
        pooled = img[:ph * pool, :pw * pool].reshape(ph, pool, pw, pool).min(axis=(1, 3))
        metres = pooled * (DEPTH_MAX_M - DEPTH_MIN_M) + DEPTH_MIN_M
        in_range = (metres > 1.0) & (metres < DETECT_MAX_RANGE_M)
        if not in_range.any():
            return None
        masks = [in_range]
        if _ndimage is not None:
            background = _ndimage.maximum_filter(np.minimum(metres, DETECT_BG_CAP_M), size=DETECT_BG_WINDOW, mode='nearest')
            masks.append(in_range & (background - metres >= DETECT_CONTRAST_M))
        rot = _rot_world_from_body(drone_rpy)
        cam = np.asarray(drone_pos, dtype=np.float64) + CAM_FORWARD_OFFSET_M * rot[:, 0] + CAM_UP_OFFSET_M * rot[:, 2]
        focal = w * 0.5 / math.tan(math.radians(DEPTH_FOV_DEG) * 0.5)
        self.last_shadow = None
        for mask in masks:
            best, shadow = self._best_candidate(mask, metres, pool, ph, pw, h, w, rot, cam, focal, expected_world, gate_m, target_z)
            if self.last_shadow is None:
                self.last_shadow = shadow
            if best is not None:
                return best
        return None

    def _best_candidate(self, mask, metres, pool, ph, pw, h, w, rot, cam, focal, expected_world, gate_m, target_z):
        max_px = max(int(DETECT_MAX_BLOB_FRAC * metres.size), DETECT_MIN_BLOB_PX)
        best = None
        best_score = None
        shadow = None
        shadow_score = None
        for rows, cols in self._components(mask):
            count = len(rows)
            if count < DETECT_MIN_BLOB_PX or count > max_px:
                continue
            if rows.max() == ph - 1 and count > DETECT_FLOOR_MAX_FRAC * metres.size:
                continue
            depths = metres[rows, cols]
            span = float(depths.max() - depths.min())
            width = int(cols.max() - cols.min() + 1)
            if count > DETECT_MERGED_MIN_FRAC * metres.size and width > DETECT_MERGED_WIDTH_FRAC * pw and (span >= DETECT_MERGED_SPAN_M):
                continue
            u = (float(cols.mean()) + 0.5) * pool
            v = (float(rows.mean()) + 0.5) * pool
            rng = float(np.median(depths))
            if not 1.0 < rng < DETECT_MAX_RANGE_M:
                continue
            if rng >= DETECT_DISTANT_MIN_RANGE_M and count > DETECT_DISTANT_MAX_FRAC * metres.size:
                continue
            ray_body = np.array([1.0, (w * 0.5 - u) / focal, (h * 0.5 - v) / focal], dtype=np.float64)
            ray_body = ray_body / float(np.linalg.norm(ray_body))
            world = cam + rot @ ray_body * rng
            if not DETECT_Z_PRIOR_MIN_M <= float(world[2]) <= DETECT_Z_PRIOR_MAX_M:
                continue
            gated_out = target_z is not None and abs(float(world[2]) - target_z) > DETECT_Z_GATE_M
            if expected_world is not None:
                err = float(np.linalg.norm(world[:2] - np.asarray(expected_world, dtype=np.float64)[:2]))
                if err > gate_m:
                    continue
                z_err = 0.0 if target_z is None else abs(float(world[2]) - target_z)
                score = err + 0.05 * rng + 4.0 * z_err
                shadow_metric = err + 0.05 * rng
            else:
                score = rng
                shadow_metric = rng
            if shadow_score is None or shadow_metric < shadow_score:
                shadow_score = shadow_metric
                shadow = world
            if gated_out:
                continue
            if best_score is None or score < best_score:
                best_score = score
                best = world
        return (best, shadow)

    @staticmethod
    def _components(mask: np.ndarray):
        if _ndimage is not None:
            labels, n = _ndimage.label(mask)
            if n == 0:
                return []
            out = []
            for idx, box in enumerate(_ndimage.find_objects(labels, max_label=n), start=1):
                if box is None:
                    continue
                local_rows, local_cols = np.nonzero(labels[box] == idx)
                if local_rows.size:
                    out.append((local_rows + box[0].start, local_cols + box[1].start))
            return out
        rows, cols = np.nonzero(mask)
        return [(rows, cols)] if rows.size else []

class DroneFlightController:
    CLIMB = 0
    TRANSIT = 1
    PURSUE = 2

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.frame = 0
        self.phase = self.CLIMB
        self.estimator = LeashEstimator()
        self.detector = DepthTargetDetector()
        self._track_pos: Optional[np.ndarray] = None
        self._track_vel = np.zeros(3, dtype=np.float64)
        self._track_t: Optional[float] = None
        self._seen = False
        self._arrival: Optional[np.ndarray] = None
        self._target_at_leash = False
        self._airborne = False
        self._stretch_side = 0.0
        self._bias_phase: Optional[float] = None
        self._goal_pinned: Optional[np.ndarray] = None
        self._dbg_station: Optional[np.ndarray] = None
        self._dbg_staging: Optional[np.ndarray] = None
        self._dbg_hold = False
        self._dbg_pin_pursue = False
        self._commit_dwell = 0.0
        self._commit_holding = False
        self._commit_rdot = 0.0
        self._prev_cmd = np.zeros(3, dtype=np.float64)
        self._detected_now = False
        self._z_history: deque = deque(maxlen=DETECT_Z_HISTORY)
        self._z_locked: Optional[float] = None
        self._z_belief: Optional[float] = None
        self._z_pending: deque = deque(maxlen=64)
        self._z_shadow: deque = deque(maxlen=64)
        self._z_last_seen = 0.0

    @staticmethod
    def _confirmed(samples, t: float, min_n: int=DETECT_Z_MIN_LOCK, window_s: float=DETECT_Z_WINDOW_S) -> Optional[float]:
        recent = [z for ts, z in samples if t - ts <= window_s]
        if len(recent) < min_n:
            return None
        if max(recent) - min(recent) > DETECT_Z_SPREAD_M:
            return None
        return float(np.median(recent))

    def _update_altitude_lock(self, t: float, detection: Optional[np.ndarray], shadow: Optional[np.ndarray]) -> None:
        if detection is not None:
            z = float(detection[2])
            self._z_last_seen = t
            if self._z_locked is None:
                self._z_pending.append((t, z))
                confirmed = self._confirmed(self._z_pending, t)
                if confirmed is not None:
                    self._z_locked = confirmed
                    self._z_belief = confirmed
                    self._z_history.clear()
                    self._z_history.append(confirmed)
                    self._z_shadow.clear()
            else:
                self._z_history.append(z)
                self._z_locked = float(np.median(self._z_history))
                self._z_belief = self._z_locked
            return
        if self._z_locked is None:
            return
        stale = t - self._z_last_seen
        if shadow is not None:
            self._z_shadow.append((t, float(shadow[2])))
            hard = PROFILE['lock_overturn'] == 'hard'
            rival = self._confirmed(self._z_shadow, t, min_n=DETECT_Z_RIVAL_MIN if hard else DETECT_Z_MIN_LOCK, window_s=DETECT_Z_RIVAL_WINDOW_S if hard else DETECT_Z_WINDOW_S)
            if rival is not None and stale >= (DETECT_Z_STALE_S if hard else DETECT_Z_STALE_EASY_S) and (abs(rival - self._z_locked) > DETECT_Z_GATE_M):
                self._z_locked = rival
                self._z_belief = rival
                self._z_history.clear()
                self._z_history.append(rival)
                self._z_pending.clear()
                self._z_shadow.clear()
                self._z_last_seen = t
                return
        if stale >= DETECT_Z_RELEASE_S:
            self._z_locked = None
            self._z_history.clear()
            self._z_pending.clear()
            self._z_shadow.clear()

    def _update_track(self, t: float, world: Optional[np.ndarray]) -> None:
        if world is None:
            return
        world = np.asarray(world, dtype=np.float64)
        if self._track_pos is not None and self._track_t is not None:
            dt = max(t - self._track_t, 0.001)
            if dt < 0.5:
                measured = (world - self._track_pos) / dt
                self._track_vel += 0.25 * (measured - self._track_vel)
                self._track_vel = _limit(self._track_vel, 7.0)
        self._track_pos = world
        self._track_t = t
        self._seen = True

    def _predicted_target(self, t: float) -> Optional[np.ndarray]:
        if self._track_pos is None or self._track_t is None:
            return None
        age = t - self._track_t
        if age > TRACK_MEMORY_S:
            return None
        return self._track_pos + self._track_vel * age

    def _intercept(self, pos: np.ndarray, vel: np.ndarray, target: np.ndarray, target_vel: np.ndarray, lead_s: float) -> np.ndarray:
        aim = target + target_vel * lead_s
        to_aim = aim - pos
        distance = float(np.linalg.norm(to_aim))
        if distance < 1e-06:
            return np.zeros(3)
        base = MAX_SPEED * (to_aim / distance)
        rel = target - pos
        rng = float(np.linalg.norm(rel))
        if rng > 1e-06:
            los = rel / rng
            rel_v = target_vel - np.asarray(vel, dtype=np.float64)
            closing = max(0.0, -float(np.dot(rel_v, los)))
            los_rate = (rel_v - float(np.dot(rel_v, los)) * los) / rng
            lateral = _limit(PN_GAIN * closing * los_rate, PN_MAX_LATERAL)
            base = MAX_SPEED * _unit(base + 0.25 * lateral)
        dz = float(target[2] - pos[2])
        if abs(dz) > ALT_MATCH_DEADBAND_M:
            vz = float(np.clip(ALT_MATCH_GAIN * dz, -MAX_CLIMB_MPS, MAX_CLIMB_MPS))
            horiz_budget = math.sqrt(max(0.0, MAX_SPEED ** 2 - vz ** 2))
            horiz = base[0:2]
            speed = float(np.linalg.norm(horiz))
            if speed > 1e-06:
                horiz = horiz / speed * min(speed, horiz_budget)
            base = np.array([horiz[0], horiz[1], vz], dtype=np.float64)
        return base

    def _altitude_rate(self, own_z: float, agl: float, desired_agl: float) -> float:
        return float(np.clip(ALT_GAIN * (desired_agl - agl), -MAX_CLIMB_MPS, MAX_CLIMB_MPS))

    def _hold_field(self, pos: np.ndarray, txy: np.ndarray, hxy: np.ndarray, target_z: float) -> np.ndarray:
        rel = np.asarray(pos, dtype=np.float64)[0:2] - txy
        r = float(np.linalg.norm(rel))
        if r < 1e-06:
            return np.zeros(3, dtype=np.float64)
        ur = rel / r
        ut = np.array([-ur[1], ur[0]], dtype=np.float64)
        v_r = -COMMIT_HOLD_KR * (r - COMMIT_HOLD_M) * ur
        want = _unit(hxy - txy)
        ang = math.atan2(float(ur[0] * want[1] - ur[1] * want[0]), float(np.dot(ur, want)))
        taper = min(1.0, abs(ang) / math.radians(COMMIT_HOLD_TAPER_DEG))
        v_t = COMMIT_HOLD_KT * MAX_SPEED * math.copysign(taper, ang) * ut
        v2 = _limit(v_r + v_t, MAX_SPEED)
        vz = float(np.clip(ALT_MATCH_GAIN * (target_z - float(pos[2])), -MAX_CLIMB_MPS, MAX_CLIMB_MPS))
        budget = math.sqrt(max(0.0, MAX_SPEED ** 2 - vz ** 2))
        n = float(np.linalg.norm(v2))
        if n > 1e-06:
            v2 = v2 / n * min(n, budget)
        return np.array([v2[0], v2[1], vz], dtype=np.float64)

    def _hold_agl(self, own_z: float, agl: float) -> float:
        if self._z_belief is None:
            return SEARCH_AGL_M
        ground = own_z - agl
        want = float(np.clip(self._z_belief - ground, TRACK_MIN_AGL_M, SEARCH_AGL_M * 2.0))
        if self.phase == self.CLIMB:
            want = max(want, CLIMB_EXIT_AGL_M)
        return want

    def debug_state(self) -> dict:
        est = self.estimator
        xy = lambda v: [float(v[0]), float(v[1])] if v is not None else None
        return {'detected': bool(self._detected_now), 'phase': int(self.phase), 'clue': xy(est.clue), 'est_home': xy(est.home), 'anchor': xy(est._anchor), 'est_leash': xy(est.leash_point), 'est_arrival': xy(self._arrival), 'est_station': xy(self._dbg_station), 'est_staging': xy(self._dbg_staging), 'est_target': xy(est.target_est), 'heading_deg': math.degrees(est.cruise_heading) if est.cruise_heading is not None else None, 'windows': int(est.windows)}

    def _finish(self, v_req: np.ndarray, yaw: float, tilt_deg: float, target_range: float) -> np.ndarray:
        v_req = np.asarray(v_req, dtype=np.float64)
        if tilt_deg > TILT_BRAKE_START_DEG:
            span = max(TILT_BRAKE_FULL_DEG - TILT_BRAKE_START_DEG, 1e-06)
            t = min(1.0, (tilt_deg - TILT_BRAKE_START_DEG) / span)
            v_req = v_req * (1.0 - (1.0 - TILT_BRAKE_MIN_FRACTION) * t)
        accel = TERMINAL_MAX_ACCEL if target_range <= TERMINAL_ACCEL_RANGE_M else NORMAL_MAX_ACCEL
        delta = v_req - self._prev_cmd
        n = float(np.linalg.norm(delta))
        cap = accel * DT
        if n > cap and n > 1e-12:
            delta = delta * (cap / n)
        v_cmd = _limit(self._prev_cmd + delta, MAX_SPEED)
        self._prev_cmd = v_cmd
        return _encode(v_cmd, yaw)

    def act(self, observation) -> np.ndarray:
        state = np.asarray(observation['state'], dtype=np.float64)
        depth = observation.get('depth') if isinstance(observation, dict) else None
        t = self.frame * DT
        self.frame += 1
        position = state[0:3]
        rpy = state[3:6]
        velocity = state[6:9]
        agl = float(state[137]) * MAX_RAY_DISTANCE_M
        clue_offset = state[138:140]
        tilt_deg = math.degrees(max(abs(float(rpy[0])), abs(float(rpy[1]))))
        est = self.estimator
        est.update(t, position[0:2], clue_offset)
        clue_xy = est.clue if est.clue is not None else position[0:2]
        pinned = est.pinned_target(t)
        if pinned is not None:
            aim_xy = pinned
        else:
            aim_xy = clue_xy
        predicted = self._predicted_target(t)
        if predicted is not None:
            expected = predicted
            gate = DETECT_GATE_M * 0.5
        else:
            expected = np.array([aim_xy[0], aim_xy[1], position[2]], dtype=np.float64)
            gate = max(DETECT_GATE_M, 25.0)
        target_z = self._z_locked
        detection = self.detector.detect(depth, position, rpy, expected, gate, target_z)
        self._update_altitude_lock(t, detection, self.detector.last_shadow)
        self._detected_now = detection is not None
        self._update_track(t, detection)
        target = self._predicted_target(t)
        pursue_target = target
        pursue_vel = self._track_vel
        self._dbg_pin_pursue = False
        if pursue_target is None and pinned is not None and (self._z_belief is not None):
            pursue_target = np.array([float(pinned[0]), float(pinned[1]), float(self._z_belief)], dtype=np.float64)
            cv = est._clue_velocity
            pursue_vel = np.array([float(cv[0]), float(cv[1]), 0.0], dtype=np.float64)
            self._dbg_pin_pursue = True
        if detection is not None:
            det_xy = np.asarray(detection, dtype=np.float64)[:2]
            est.observe_target(t, det_xy)
            est.pin_offset(t, det_xy)
        if not self._target_at_leash:
            if target is not None and est.home is not None and (float(np.linalg.norm(np.asarray(target)[:2] - est.home)) >= LEASH_M - ENGAGE_ARRIVAL_MARGIN_M):
                self._target_at_leash = True
            elif t >= LEASH_ARRIVAL_S:
                self._target_at_leash = True
        if agl >= CLIMB_EXIT_AGL_M:
            self._airborne = True
        engaged = self._target_at_leash or PROFILE['engagement'] == 'on_sight'
        if pursue_target is not None and self._airborne and engaged:
            self.phase = self.PURSUE
        elif self.phase == self.CLIMB and agl >= CLIMB_EXIT_AGL_M:
            self.phase = self.TRANSIT
        elif self.phase == self.PURSUE:
            self.phase = self.TRANSIT
        yaw_to_clue = math.atan2(float(aim_xy[1] - position[1]), float(aim_xy[0] - position[0]))
        sweep = PROFILE['sweep'] == 'when_unpinned' and pinned is None and (not self._detected_now) or (PROFILE['sweep'] == 'when_blind' and (not self._detected_now))
        if sweep:
            yaw_to_clue += math.radians(SWEEP_AMP_DEG) * math.sin(2.0 * math.pi * t / SWEEP_PERIOD_S)
        if self.phase == self.PURSUE and pursue_target is not None:
            target = pursue_target
            rel = target - position
            rng = float(np.linalg.norm(rel))
            yaw = math.atan2(float(rel[1]), float(rel[0]))
            self._dbg_hold = False
            txy = np.asarray(target, dtype=np.float64)[:2]
            los = txy - position[0:2]
            r2 = float(np.linalg.norm(los))
            if r2 > 1e-06:
                los_u = los / r2
                v_use = np.asarray(pursue_vel, dtype=np.float64)[:2]
                self._commit_rdot = COMMIT_RDOT_SMOOTH * self._commit_rdot + (1.0 - COMMIT_RDOT_SMOOTH) * float(np.dot(v_use, los_u))
            if r2 <= REACT_M:
                self._commit_dwell += DT
            if not self._commit_holding and self._commit_dwell > COMMIT_DWELL_S and (r2 > COMMIT_TERMINAL_M):
                self._commit_holding = True
            if self._commit_holding and self._commit_rdot < COMMIT_APPROACH_MPS:
                self._commit_holding = False
                self._commit_dwell = 0.0
            if self._commit_holding and est.home is not None:
                self._dbg_hold = True
                hxy = np.asarray(est.home, dtype=np.float64)
                inb = _unit(hxy - txy)
                goal = np.array([txy[0] + inb[0] * COMMIT_HOLD_M, txy[1] + inb[1] * COMMIT_HOLD_M, float(target[2])], dtype=np.float64)
                v_cmd = _limit((goal - position) * COMMIT_HOLD_GAIN, MAX_SPEED)
                return self._finish(v_cmd, yaw, tilt_deg, r2)
            lead = TERMINAL_LEAD_S if rng < TERMINAL_RANGE_M else PURSUE_LEAD_S
            v_cmd = self._intercept(position, velocity, target, pursue_vel, lead)
            return self._finish(_limit(v_cmd, MAX_SPEED), yaw, tilt_deg, rng)
        if self.phase == self.CLIMB:
            climb = self._altitude_rate(float(position[2]), agl, self._hold_agl(float(position[2]), agl))
            lateral = np.zeros(2)
            if est.leash_point is not None:
                lateral = _unit(est.leash_point - position[0:2]) * (MAX_SPEED * 0.35)
            return self._finish(np.array([lateral[0], lateral[1], climb]), yaw_to_clue, tilt_deg, 1000000000.0)
        final_leg_t = LEASH_ARRIVAL_S - STAGING_M / ACHIEVED_SPEED_MPS
        self._dbg_station = est.station_point(position[0:2])
        self._dbg_staging = est.staging_point(position[0:2])
        picked = self._dbg_station if t >= final_leg_t else self._dbg_staging
        if picked is not None:
            self._arrival = picked
        goal = self._arrival
        if goal is None:
            to_clue = np.asarray(aim_xy, dtype=np.float64) - position[0:2]
            distance = float(np.linalg.norm(to_clue))
            speed = MAX_SPEED if distance > REACT_M + 6.0 else MAX_SPEED * 0.25
            planar = _unit(to_clue) * speed
            climb = self._altitude_rate(float(position[2]), agl, self._hold_agl(float(position[2]), agl))
            return self._finish(np.array([planar[0], planar[1], climb]), yaw_to_clue, tilt_deg, 1000000000.0)
        steer_at = np.asarray(goal, dtype=np.float64)
        to_goal = np.asarray(steer_at, dtype=np.float64) - position[0:2]
        distance = float(np.linalg.norm(np.asarray(goal, dtype=np.float64) - position[0:2]))
        if distance > ARRIVAL_SETTLE_M:
            speed = MAX_SPEED
        else:
            speed = MAX_SPEED * float(np.clip(distance / ARRIVAL_SETTLE_M, 0.0, 1.0)) * 0.6
        planar = _unit(to_goal) * speed
        keep_out = np.asarray(clue_xy, dtype=np.float64)
        keep_out_m = STANDOFF_HOLD_M
        if target is not None:
            keep_out = np.asarray(target, dtype=np.float64)[:2]
            keep_out_m = ENGAGE_STANDOFF_M
        gap = float(np.linalg.norm(keep_out - position[0:2]))
        if gap < keep_out_m:
            away = _unit(position[0:2] - keep_out)
            planar = planar + away * (MAX_SPEED * 0.5)
            planar = _limit(planar, MAX_SPEED)
        climb = self._altitude_rate(float(position[2]), agl, self._hold_agl(float(position[2]), agl))
        return self._finish(np.array([planar[0], planar[1], climb]), yaw_to_clue, tilt_deg, 1000000000.0)
